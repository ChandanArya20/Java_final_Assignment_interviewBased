package in.ineuron.model;

public class User {

}
