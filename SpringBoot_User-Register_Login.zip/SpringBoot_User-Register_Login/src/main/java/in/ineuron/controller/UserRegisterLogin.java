package in.ineuron.controller;

import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import in.ineuron.entites.LoginData;
import in.ineuron.entites.RegisterData;
import in.ineuron.repository.UserRepository;

@Controller
public class UserRegisterLogin {
	
	@Autowired
	private UserRepository repo;

	@GetMapping("/regForm")
	public String showRegisterPage(Model model) {
		model.addAttribute("registerData",new RegisterData());
		return "register";
	}
	
	@PostMapping("/register")
	public String registerUser(@Valid @ModelAttribute RegisterData registerData, BindingResult result, Model model) {
		
		if(result.hasErrors()) {
			return "register";
		}	
		repo.save(registerData);
		return "registerSuccess";		
	}
	
	@PostMapping("/login")
	public String loginUser(@Valid @ModelAttribute LoginData loginData, BindingResult result, Model model){
		
		boolean loginFailed=false;
		
		if(result.hasErrors()) {
			return "loginForm";
		}
		RegisterData registeredData = repo.findById(loginData.getEmail()).orElse(null);
		if (registeredData != null && registeredData.getPassword().equals(loginData.getPassword()))
	        return "loginSuccess";
	    else {
	        loginFailed = true;
	        model.addAttribute("loginFailed",loginFailed);
	        return "loginForm";
	    }
	}
	@GetMapping("/logForm")
	public String showLoginPage(Model model) {
		System.out.println("UserRegisterLogin.showLoginPage()");
		model.addAttribute("loginData",new LoginData());
		return "loginForm";
	}
}
