package in.ineuron.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import in.ineuron.entites.RegisterData;

public interface UserRepository extends JpaRepository<RegisterData, String> {

}
