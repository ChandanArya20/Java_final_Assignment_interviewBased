package in.ineuron;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootUserRegisterLoginApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootUserRegisterLoginApplication.class, args);
	}

}
