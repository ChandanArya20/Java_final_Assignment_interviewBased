package in.ineuron.entites;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class LoginData {
	
	@NotBlank(message = "email should not be empty")
	@Email(regexp = "^(?=[a-zA-Z0-9@.!#$%&'*+/=?^_`{|}~-]{6,254}$)[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$", 
						message="invalid email!")
	private String email;
	
	@NotBlank(message = "password should not be empty")
    @Pattern(regexp = "^(?=.*[A-Z])(?=.*[a-z])(?=.*\\d)(?=.*[!@#$%^&*()\\-_=+{};:,<.>])(?=.*[^\\w\\d\\s])(?!.*\\s).{8,}$",
             message = "password is week, make it strong...")
	private String password;
	

	
}
