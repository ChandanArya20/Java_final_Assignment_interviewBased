package in.ineuron.abstractclass;

public class Student extends Person{

	@Override
    void eat() {
        System.out.println("Student is eating");
    }

    @Override
    void sleep() {
        System.out.println("Student is sleeping");
    }
    
    //specialized method
    void study() {
    	System.out.println("Student is studying");
    }
}


