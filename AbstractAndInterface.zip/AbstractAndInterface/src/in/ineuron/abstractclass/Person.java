package in.ineuron.abstractclass;

public abstract class Person {
	
	//Abstract methods
	abstract void eat();
	abstract void sleep();
	
	// Concrete method
    void speak() {
        System.out.println("I can speak!");
    }	
	
}

/*

1) An abstract class cannot be instantiated, means we cannot create objects of an abstract class.
2) Abstract class can have abstract method and concrete method or any one them.
3) when abstract classes have abstract methods, which are declared without an implementation and 
	must be overridden in the concrete subclasses.
4) When abstract classes have non-abstract methods then their implementation should be there in abstract class.
5) Concrete subclasses of an abstract class must implement all the abstract methods of the abstract class 
	or be declared abstract themselves otherwise We have to make concrete class as abstract class.
6) Abstract class cannot extends multiple abstract classes.
6) Abstract classes can have instance variables, constructors.

*/
