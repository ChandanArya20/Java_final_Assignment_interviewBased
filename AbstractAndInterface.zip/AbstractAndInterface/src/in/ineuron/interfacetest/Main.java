package in.ineuron.interfacetest;

public class Main {

	public static void main(String[] args) {
		
		Vehicle vehicle = new Car();	
		vehicle.start();
		vehicle.stop();
		
		vehicle=new Bike();
		vehicle.start();
		vehicle.stop();
			

	}

}
