package in.ineuron.interfacetest;

interface Vehicle {
	
    void start();
    void stop();
}

/*

 1) An interface only keep abstract methods that implementing classes must provide an implementation for them but
 	In Java 8 and later, interfaces can also have default and static methods with an implementation.
 2) interfaces cannot have instance variables or constructors.
 3) All methods in an interface are implicitly public and abstract. 
 4) A class can implement multiple interfaces, allowing for multiple inheritance.
 5) Interface can extends multiple interface.
 6) Interfaces are used to achieve polymorphism and provide a way to define common behavior across unrelated classes.

*/
