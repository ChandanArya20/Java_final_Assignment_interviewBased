package in.ineuron.interfacetest;

public class Car implements Vehicle{

		@Override
	    public void start() {
	        System.out.println("Car started");
	    }

	    @Override
	    public void stop() {
	        System.out.println("Car stopped");
	    }
	    
	    //specialized method	    
        public int getNumberOfWheel() {
	    	return 4;
	    }
	    
	
}


