package in.ineuron;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import in.ineuron.model.OrderTable;
import in.ineuron.model.User;
import in.ineuron.repo.OrderTableRepository;
import in.ineuron.repo.UserRepository;

@SpringBootApplication
public class SpringBootInsertAppApplication {
	
	@Autowired
	private OrderTableRepository Repository ;

	public static void main(String[] args) {
		ConfigurableApplicationContext app = SpringApplication.run(SpringBootInsertAppApplication.class, args);
		
//		OrderTable order1 = new OrderTable(null,"Soap",new User(null,"Chandan"));
//		OrderTable order2 = new OrderTable(null,"Mouse",new User(null,"Arya"));
//		OrderTable order3 = new OrderTable(null,"Laptop",new User(null,"Muskan"));
//		
		OrderTableRepository repo = app.getBean(OrderTableRepository.class);
//		
//		repo.save(order1);
//		repo.save(order2);
//		repo.save(order3);							
//		System.out.println("Record inserted successfully...");		
		
		List<OrderTable> list = repo.findByUser(new User(5,"Chandan"));
		System.out.println(list);
	}

}













