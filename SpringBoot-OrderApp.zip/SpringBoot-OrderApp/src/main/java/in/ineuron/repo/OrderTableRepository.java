package in.ineuron.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import in.ineuron.model.OrderTable;
import in.ineuron.model.User;

public interface OrderTableRepository extends JpaRepository<OrderTable, Integer> {
	 List<OrderTable> findByUser(User user);
}
