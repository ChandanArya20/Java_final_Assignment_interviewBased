
public class Child extends Parent{
	
	//zero param constructor
	Child(){
		
		System.out.println("child class constructor got invoked");
	}
	
	//one param constructor
	Child(Object data){
		
		super(data);
		System.out.println("child class constructor got invoked");
	}
}
