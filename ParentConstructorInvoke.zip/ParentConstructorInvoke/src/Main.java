
public class Main {

	public static void main(String[] args) {
		
		Child child1 = new Child();
		
		System.out.println();
		
		Child child2 = new Child("Hi dad");

	}

}

/*

 1) Constructors are special methods that are automatically at the time of object creation, normally used to 
 	initialize instance variable of a object.
 2) The name of the constructor must be the same as the class name.
 3) Constructors do not have a any return type
 4) If a class does not define any constructors, a default constructor (with no arguments) is automatically 
 	provided by the compiler.
 5) If a class defines at least one constructor, the default constructor is not automatically provided unless 
 	it is explicitly defined.
 6) Constructors can be overloaded, meaning a class can have multiple constructors with different parameter lists.
 7) Constructors can also call other constructors within the same class using the this() method, allowing for 
 	constructor chaining.
 8) Constructors are not inherited but can be invoked by the subclass using the super() method to call the parent 
 	class constructor.

 */