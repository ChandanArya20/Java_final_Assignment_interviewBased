
public class Parent {
	
	//zero param constructor
	Parent(){
		System.out.println("Parent class constructor got invoked");
	}
	
	//one param constructor
	Parent(Object childData){
		System.out.println("Parent class constructor got invoked");
		System.out.println("Data coming from child class : "+childData);
	}
}
