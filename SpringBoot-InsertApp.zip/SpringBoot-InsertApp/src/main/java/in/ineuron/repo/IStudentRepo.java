package in.ineuron.repo;

import org.springframework.data.repository.CrudRepository;

import in.ineuron.model.Student;

public interface IStudentRepo extends CrudRepository<Student, Integer> {

}
