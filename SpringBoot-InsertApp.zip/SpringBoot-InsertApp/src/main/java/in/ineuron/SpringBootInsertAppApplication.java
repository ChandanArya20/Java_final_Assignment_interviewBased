package in.ineuron;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import in.ineuron.model.Student;
import in.ineuron.repo.IStudentRepo;

@SpringBootApplication
public class SpringBootInsertAppApplication {
	
	@Autowired
	private IStudentRepo repo;

	public static void main(String[] args) {
		ConfigurableApplicationContext app = SpringApplication.run(SpringBootInsertAppApplication.class, args);
		
		Student std = new Student();
		std.setSid(null);
		std.setSname("Krishna");
		std.setSage(25);
		std.setSaddress("Mathura");
		
		IStudentRepo service = app.getBean(IStudentRepo.class);
		service.save(std);
		
		System.out.println("Record inserted successfully...");		
	}

}
