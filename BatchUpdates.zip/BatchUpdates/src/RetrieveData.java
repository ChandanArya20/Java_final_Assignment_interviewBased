import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class RetrieveData {
	

	public static void main(String[] args) {
		
		String url="jdbc:mysql://localhost:3306/studentproject";
		String userName="root";
		String password="2002ckc+";
		
		String sqlQuery="SELECT * FROM studentrecord";
		
		Connection connection=null;
		PreparedStatement stm=null;
		ResultSet resultSet =null;
		
		try {
			connection=DriverManager.getConnection(url, userName, password);
			
			if(connection!=null)
				stm=connection.prepareStatement(sqlQuery);
			
			if(stm!=null) 
				resultSet = stm.executeQuery();
			
			if(resultSet.next()) {
				
				System.out.println("Id\tName\tAge\tAddress");
				System.out.println("------------------------------------------");
				while(resultSet.next()) {
					System.out.println(resultSet.getInt(1)+"\t"+resultSet.getString(2)+"\t"+
										resultSet.getInt(3)+"\t"+resultSet.getString(4));
				}
				
			}else
				System.out.println("Database is empty..., No data found");
							
			
		} catch (SQLException e) {
			e.printStackTrace();
			
		}

	}

}
