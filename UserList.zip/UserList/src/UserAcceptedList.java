import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class UserAcceptedList {
	
    public static void main(String[] args) {
    	
        Scanner scanner = new Scanner(System.in);
        List<Integer> numbers = new ArrayList<>();

        System.out.print("Enter the number of integers: ");
        int IntegerCount = scanner.nextInt();

        System.out.println("Enter the integers:");

        for (int i = 0; i < IntegerCount; i++) {
            int num = scanner.nextInt();
            numbers.add(num);
        }

        Collections.sort(numbers);
        
        // Find the second largest and second smallest elements
        int secondLargest = numbers.get(numbers.size() - 2);
        int secondSmallest = numbers.get(1);

        System.out.println("Second Largest: " + secondLargest);
        System.out.println("Second Smallest: " + secondSmallest);
        
        scanner.close();
    }
    
}
