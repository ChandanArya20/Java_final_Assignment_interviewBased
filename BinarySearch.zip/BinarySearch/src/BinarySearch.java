import java.util.Scanner;

public class BinarySearch {

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		
		int[] arr= {2,10,23,40,49,67,75,80,89,90,110,115,122,200,204,344,};
		
		System.out.print("Enter element to search : ");
		int key=scanner.nextInt();
		
		int l=0;
		int h=arr.length-1;
		
		while(l<h) {
			
			int mid=l+h;
			if(arr[mid]==key) {
				System.out.println("Element fount at index "+mid);
				break;
			}else if(key<arr[mid]) {
				h=mid-1;
			}else {
				l=mid+1;
			}
			
		}
		if(l>h) {
			System.out.println("Element not found in array...");
		}
		
		scanner.close();

	}

}
