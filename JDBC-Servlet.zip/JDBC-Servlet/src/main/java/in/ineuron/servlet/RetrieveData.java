package in.ineuron.servlet;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/")
public class RetrieveData extends HttpServlet{
	
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
				
		String url="jdbc:mysql://localhost:3306/studentproject";
		String userName="root";
		String password="2002ckc+";
		
		String sqlQuery="SELECT * FROM studentrecord";
		
		Connection connection=null;
		PreparedStatement stm=null;
		ResultSet resultSet =null;
		
		PrintWriter out = response.getWriter();
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			connection=DriverManager.getConnection(url, userName, password);
			
			if(connection!=null)
				stm=connection.prepareStatement(sqlQuery);
			
			if(stm!=null) 
				resultSet = stm.executeQuery();
			
			if(resultSet.next()) {		
				out.println("<body><table>");
				
				while(resultSet.next()) {
					
					int id = resultSet.getInt(1);
	                String name = resultSet.getString(2);
	                int age = resultSet.getInt(3);
	                String address=resultSet.getString(4);
	                out.println("<tr><td>" + id + "</td><td>" + name + "</td><td>" + age + "</td><td>"+ address + "</td></tr>");
				
				}
				
				out.println("<body><table>");
				
			}else
				out.println("<h1>Database is empty..., No data found</h1>");
			
			
		} catch (SQLException | ClassNotFoundException e) {
			e.printStackTrace();
			out.println("<h1 style='color:red; text-align:center;'>Something went wrong....</h1>");
		
		}
	}
		

}
