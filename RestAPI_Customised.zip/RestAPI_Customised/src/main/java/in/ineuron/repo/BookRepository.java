package in.ineuron.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import in.ineuron.model.Book;

public interface BookRepository extends JpaRepository<Book, Long> {

}
