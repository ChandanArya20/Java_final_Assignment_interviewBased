package in.ineuron.controller;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import in.ineuron.model.Book;
import in.ineuron.repo.BookRepository;


@RestController
@RequestMapping("/book")
public class BookController {
	
		@Autowired
		BookRepository repo;
	
		@GetMapping("/all")
		public ResponseEntity<List<Book>> getAllBooks(){			
			try {
				return ResponseEntity.ok(repo.findAll());
			} catch (Exception e) {
				e.printStackTrace();
				return ResponseEntity.internalServerError().build();
			}		
		}
		
		@GetMapping("/genre")
		public ResponseEntity<List<Book>> getBooksByFilter(@RequestParam String genre){	
			System.out.println("BookController.getBooksByFilter()");
			try {					
				List<Book> list=repo.findAll();
				list = list.stream().filter(book->book.getGenre().equalsIgnoreCase(genre)).collect(Collectors.toList());
				return ResponseEntity.ok(list);				
				
			} catch (Exception e) {
				e.printStackTrace();
				return ResponseEntity.internalServerError().build();
			}		
		}
		@GetMapping("/page/{pageNo}/{pageSize}")
		public ResponseEntity<List<Book>> getBooksByPagination(@PathVariable int pageNo, @PathVariable int pageSize){		
			try {	
				List<Book> list = repo.findAll(PageRequest.of(pageNo, pageSize)).getContent();
				return ResponseEntity.ok(repo.findAll(PageRequest.of(pageNo, pageSize)).getContent());			
				
			} catch (Exception e) {
				e.printStackTrace();
				return ResponseEntity.internalServerError().build();
			}		
		}
		@GetMapping("/{field}")
		public ResponseEntity<List<Book>> getBooksBysort(@PathVariable String field){		
			try {	
				List<Book> list = repo.findAll(Sort.by(Sort.Direction.ASC, field));
				return ResponseEntity.ok(list);			
				
			} catch (Exception e) {
				e.printStackTrace();
				return ResponseEntity.internalServerError().build();
			}		
		}
		
		@GetMapping
	    public List<Book> getBookBySortingAndPagination(@RequestParam(required = false) String genre,
	                               @RequestParam(defaultValue = "0") int page,
	                               @RequestParam(defaultValue = "10") int size) {
	        if (genre != null) {
	            return 	 repo.findAll().stream()
	                    .filter(book -> book.getGenre().equalsIgnoreCase(genre))
	                    .skip(page * size)
	                    .limit(size)
	                    .collect(Collectors.toList());
	        }
	        return   repo.findAll().stream()
	                .skip(page * size)
	                .limit(size)
	                .collect(Collectors.toList());
	    }
			   
}












