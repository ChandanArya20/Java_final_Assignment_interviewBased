package in.ineuron.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.ineuron.model.Product;
import in.ineuron.repo.ProductRepo;

@RestController
@RequestMapping("/products")
public class ProductController {
	
		@Autowired
		ProductRepo repo;
	
		@GetMapping("/findAll")
	    public ResponseEntity<List<Product>> getAllProducts() {
			
			List<Product> list = (List<Product>) repo.findAll();
	        return ResponseEntity.ok(list);
	    }

	    @GetMapping("/find/{id}")
	    public ResponseEntity<Product> getProductById(@PathVariable Integer id) {
	    	
	        try {
				Product product = repo.findById(id).orElse(null);
				if (product != null) {
				    return ResponseEntity.ok(product);
				}
				return ResponseEntity.notFound().build();
			} catch (Exception e) {
				e.printStackTrace();
				return ResponseEntity.internalServerError().build();
			}
	    }

	    @PostMapping("/add")
	    public ResponseEntity<Product> createProduct(@RequestBody Product product) {
	       
	        return ResponseEntity.status(HttpStatus.CREATED).body(repo.save(product));
	    }

	    @PutMapping("/modify/{id}")
	    public ResponseEntity<Product> updateProduct(@RequestBody Product updatedProduct) {
	    	
	    	Optional<Product> product = repo.findById(updatedProduct.getPid());
	        if (product.isPresent()) {
	        	Product prod = product.get();
	            prod.setPname(updatedProduct.getPname());
	            prod.setPrice(updatedProduct.getPrice());
	            prod = repo.save(prod);
	            return ResponseEntity.ok(prod);
	        }
	        return ResponseEntity.notFound().build();
	    }

	    @DeleteMapping("/delete/{id}")
	    public ResponseEntity<Product> deleteProduct(@PathVariable Integer id) {
	    	
	    	Optional<Product> product = repo.findById(id);
	        if (product.isPresent()) {
	        	repo.deleteById(id);
	            return ResponseEntity.ok(product.get());
	        }
	        return ResponseEntity.notFound().build();
	    }

}
