package in.ineuron.repo;

import org.springframework.data.repository.CrudRepository;

import in.ineuron.model.Product;

public interface ProductRepo extends CrudRepository<Product, Integer> {

}
