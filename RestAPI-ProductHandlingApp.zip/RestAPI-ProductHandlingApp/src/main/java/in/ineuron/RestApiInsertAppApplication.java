package in.ineuron;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestApiInsertAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestApiInsertAppApplication.class, args);
	}

}
