package in.ineuron.aspects;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

@Component
@Aspect
public class MethodLoggingAspects {

	    @Before("execution(* in.ineuron.service.*.*(..))")
	    public void logBefore(JoinPoint joinPoint) {
	        System.out.println("Before method: " + joinPoint.getSignature().getName());
	        Object[] args = joinPoint.getArgs();
	        for (Object arg : args) {
	            System.out.println("Input parameter: " + arg);
	        }
	    }
	    
	    @AfterReturning(pointcut = "execution(* in.ineuron.service.*.*(..))", returning = "result")
	    public void logAfterReturning(JoinPoint joinPoint, Object result) {
	        System.out.println("After method: " + joinPoint.getSignature().getName());
	        System.out.println("Output parameter: " + result);
	    }
}
