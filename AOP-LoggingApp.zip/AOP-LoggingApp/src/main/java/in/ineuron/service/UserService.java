package in.ineuron.service;

import org.springframework.stereotype.Service;

@Service
public class UserService {
	
    public String getUser(String username) {
        System.out.println("getUser method called with username: " + username);
        return "User is " + username;
    }
    
    public void saveUser(String username) {
        System.out.println("saveUser method called with username: " + username);
    }
}
