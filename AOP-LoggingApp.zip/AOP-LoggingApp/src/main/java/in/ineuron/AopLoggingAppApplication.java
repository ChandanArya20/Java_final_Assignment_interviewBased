package in.ineuron;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import in.ineuron.service.UserService;

@SpringBootApplication
public class AopLoggingAppApplication {
	
	@Autowired
	private UserService userService;

	public static void main(String[] args) {
		ConfigurableApplicationContext beanFactory = SpringApplication.run(AopLoggingAppApplication.class, args);
		
		UserService service = beanFactory.getBean(UserService.class);
		
		    service.getUser("Chandan");
		    service.saveUser("Arya");
	}

}
