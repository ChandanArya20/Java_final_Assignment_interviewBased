package in.ineuron.main;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import in.ineuron.model.Student;

public class UpdateApp {

	public static void main(String[] args) {
		
		SessionFactory sessionFactory =null;
		Session session =null;
		boolean flag=false;
		
		Integer id=56;
		
		try {
			sessionFactory = new Configuration().configure().addAnnotatedClass(Student.class).buildSessionFactory();
			
			if(sessionFactory!=null)
				session = sessionFactory.openSession();			
			
			Student std = session.get(Student.class, id);
			if(std!=null) {
				
				session.beginTransaction();
				
				System.out.println("Before Update data------>");
				System.out.println("Stdent id      : "+std.getSid());
				System.out.println("Stdent name    : "+std.getSname());
				System.out.println("Stdent age     : "+std.getSage());
				System.out.println("Stdent address : "+std.getSaddress());
				
				std.setSaddress("Singhchhapar");
				session.update(std);													
				session.getTransaction().commit();
				
				Student student = session.get(Student.class, std.getSid());
				System.out.println("\nAfter Update data------>(Address)");
				System.out.println("Stdent id      : "+std.getSid());
				System.out.println("Stdent name    : "+student.getSname());
				System.out.println("Stdent age     : "+student.getSage());
				System.out.println("Stdent address : "+student.getSaddress());			
				
			}
						
		} catch(Exception e) {
			e.printStackTrace();
		} finally {	
			
			if(session!=null)
				session.close();
			
			if(sessionFactory!=null)
				sessionFactory.close();
		}
	}
}





