import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;


public class CrudApp {
	
	private static String url="jdbc:mysql://localhost:3306/studentproject";
	private static String userName="root";
	private static String password="2002ckc+";
	
	private static Connection connection=null;
	private static PreparedStatement pstm=null;
	private static ResultSet resultSet =null;
	
	private static Integer id=null;
	private static String name=null;
	private static Integer age=null;
	private static String address=null;
	private static String msg=null;
	private static Scanner scanner=new Scanner(System.in);
	
	static {
		try {
			connection=DriverManager.getConnection(url,userName,password);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		
		
		while(true) {			
			System.out.println("\n1. Add Record");
			System.out.println("2. view Record");
			System.out.println("3. Delete Record");
			System.out.println("4. Update Record");
			System.out.println("5. See All Records");
			System.out.println("6. Exit");
			System.out.print("Enter your choice [1-6]: ");
	        int choice = scanner.nextInt();
			
			switch(choice) {			
				case 1 : System.out.print("Enter Name    : ");
						 name=scanner.next();
						 System.out.print("Enter Age     : ");
						 age=scanner.nextInt();
						 System.out.print("Enter Address : ");
						 address=scanner.next();				
						 insertStudent(name,age,address);
						 break;
		
				case 2 : System.out.print("Enter the student_id : ");
						 id=scanner.nextInt();
						 resultSet=searchStudent(id);
						 if(resultSet!=null) {
							 try {
								if(resultSet.next()) {
										
										System.out.println("Id\tName\tAge\tAddress");
										System.out.println("------------------------------------------");
										System.out.println(resultSet.getInt(1)+"\t"+resultSet.getString(2)+"\t"+
														   resultSet.getInt(3)+"\t"+resultSet.getString(4));
									}else
										System.out.println("Record not found for the id "+id);
							} catch (SQLException e) {
								System.out.println("Something went wrong...");
							}
						 }
						 break;
						 
				case 3 : System.out.print("Enter the student_id : ");
						 id=scanner.nextInt();					
						 deleteStudent(id);
						 break;
						 
				case 4 : System.out.println("Enter the student_id : ");
						 id=scanner.nextInt();
						 updateStudent(id);
					     break;
				case 5 : fetchAllRecords();
						 break;
				case 6 : System.out.println("Thanks for using our application...");
						 System.exit(0);
				
				default : System.out.println("You entered wronng choice, Please enter between 1 to 5");			
			}			
			
		}

	}
	
	private static void insertStudent(String name,int age,String address) {
		
		String query ="insert into studentrecord(sname,sage,saddress)values(?,?,?)";
		
		try {			
			if(connection!=null)
				pstm=connection.prepareStatement(query);
		 
			if(pstm!=null) {

				pstm.setString(1, name);
				pstm.setInt(2, age);
				pstm.setString(3, address);
			
				int rowCount=pstm.executeUpdate();
				
				if(rowCount==1)
					System.out.println("record inserted succesfully");
				else
					System.out.println("record insertion failed....");
			}
			
		} catch (SQLException  e) {	
			System.out.println("record insertion failed....");
		}
	}
	
	private static ResultSet searchStudent(Integer id) {
		
		String query="select * from studentrecord where sid =?";
		try {		
			if(connection!=null)
				pstm=connection.prepareStatement(query);
			
			if(pstm!=null)
				pstm.setInt(1, id);
			
			return pstm.executeQuery();		
			
		} catch (SQLException e) {
			System.out.println("Something went wrong...");
		}
		return resultSet;
	}
	
	private static void deleteStudent(Integer id) {	
		
		String query ="delete from studentrecord where sid=?";	
		try {			
			if(connection!=null)
				pstm=connection.prepareStatement(query);
		 
			if(pstm!=null) {
				
				pstm.setInt(1, id);
				int rowCount=pstm.executeUpdate();
				
				if(rowCount==1)
					System.out.println("Record deleted successfully...");
				else
					System.out.println("Record not available for given id : "+id);
			}
			
		} catch (SQLException e) {	
			System.out.println("Record Deletion failed....");	
		}
	}
	private static void updateStudent(Integer id) {
		
		String query ="update studentrecord set sname=?, sage=?, saddress=? where sid=?";
		
		resultSet=searchStudent(id);	
		try {				
			if(resultSet!=null && resultSet.next()) {
				System.out.println("Stuent id is "+resultSet.getInt(1));
				System.out.println("Old name is "+resultSet.getString(2)+" ,Enter new name : ");
				name=scanner.next();
				System.out.println("Old age is "+resultSet.getInt(3)+" ,Enter new age : ");
				age=scanner.nextInt();
				System.out.println("Old address is "+resultSet.getString(4)+" ,Enter new address : ");
				address=scanner.next();		
			}
			
			if(connection!=null)
				pstm=connection.prepareStatement(query);	
			
			if(pstm!=null) {						
				pstm.setString(1, name);
				pstm.setInt(2, age);
				pstm.setString(3, address);
				pstm.setInt(4, id);
				
				int rowCount=pstm.executeUpdate();
				
				if(rowCount==1)
					System.out.println("Record updated successfully...");
				else
					System.out.println("Record not found...");
			}
			
		} catch (SQLException e) {	
			System.out.println("something went wrong..., Record updation failed... ");
		}
	}
	private static void fetchAllRecords() {
		
		String sqlQuery="SELECT * FROM studentrecord";
		try {	
			if(connection!=null)
				pstm=connection.prepareStatement(sqlQuery);
			
			if(pstm!=null) 
				resultSet = pstm.executeQuery();
			
			if(resultSet.next()) {
				
				System.out.println("\nId\tName\tAge\tAddress");
				System.out.println("------------------------------------------");
				while(resultSet.next()) {
					System.out.println(resultSet.getInt(1)+"\t"+resultSet.getString(2)+"\t"+
										resultSet.getInt(3)+"\t"+resultSet.getString(4));
				}
				
			}else
				System.out.println("Database is empty..., No data found");
							
			
		} catch (SQLException e) {
			System.out.println("Something went wrong...");		
		}
		
	}

}
