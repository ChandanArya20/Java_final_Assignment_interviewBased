package in.ineuron.main;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import in.ineuron.model.Student;

public class RetrieveApp {

	public static void main(String[] args) {
		
		SessionFactory sessionFactory =null;
		Session session =null;
		
		try {
			sessionFactory = new Configuration().configure().addAnnotatedClass(Student.class).buildSessionFactory();
			
			if(sessionFactory!=null) {
				session = sessionFactory.openSession();			
			}
			
			if(session!=null) {
				Student student = session.get(Student.class, 122);
				
			if(student!=null)	
				System.out.println(student);
			else
				System.out.println("Data not found for given id....");
				
			}
			
		} catch (HibernateException e) {
			e.printStackTrace();
		} catch(Exception e) {
			e.printStackTrace();
		}		
	}
}
