import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

public class StreamAPI {

    public static void main(String[] args) {

        List<Integer> numbers = List.of(23, 45, 2, 34, 89, 54, 32, 234, 67, 1, 7, 8, 12, 3, 4556, 556, 334, 10);

        // Sorting the numbers in descending order
        List<Integer> list1 = numbers.stream()
                					 .sorted((n1, n2) -> n2.compareTo(n1))
                					 .collect(Collectors.toList());
        list1.forEach(n -> System.out.print(n + " "));
        System.out.println();

        // Converting the numbers into a set
        Set<Integer> set = numbers.stream()
                				  .collect(Collectors.toSet());
        set.forEach(n -> System.out.print(n + " "));
        System.out.println();

        // Filtering the even numbers
        List<Integer> list2 = numbers.stream()
                					 .filter(n -> n % 2 == 0)
                					 .toList();
        list2.forEach(n -> System.out.print(n + " "));
        System.out.println();

        // Mapping each number to its double
        List<Integer> doubledList = numbers.stream()
                .map(n -> n * 2)
                .toList();
        System.out.println(doubledList);

        // Creating a map with each number as the key and its incremented value as the value
        Map<Integer, Integer> map = doubledList.stream()
                							   .collect(Collectors.toMap(n -> n, n -> n + 2));
        System.out.println(map);

        // Calculating the sum of all numbers using reduce
        Optional<Integer> result = doubledList.stream()
                .reduce((n1, n2) -> n1 + n2);
        int sum = result.orElse(0);
        System.out.println("Sum of stream data: " + sum);
    }
}





//		List<Integer> list3 = List.of(2,3,4,5);
//		
//		Optional<Integer> optional = list3.stream().reduce((n1,n2)->{
//			
//			int total=n1+n2;
//			
//			if(currentIndex==list.size()-1)
//				return total/list.size();
//			
//			return total;
//		});
//		
//		System.out.println(optional.orElse(0));
//		