package in.ineuron.main;

import java.util.Scanner;
import in.ineuron.exception.NegativeNumberException;

public class Main {

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);	
		
		try {
			
			System.out.print("Enter a number : ");
			int num =scanner.nextInt();
			
			if(num<0)
				throw new NegativeNumberException("Number is negative");
			
		} catch(NegativeNumberException ne){
			
			ne.printStackTrace();
			ne.getMessage();
			
		} catch(Exception e) {
			e.printStackTrace();
			
		} finally {
			scanner.close();
		}

	}

}
