package in.ineuron.shape;

public class Triangle implements Shape{

	//variables for storing three sides of triangle
	private float side1;
	private float side2;
	private float side3;
	
	//constructor for initialize the variables	
	Triangle(float side1,float side2, float side3){
		
		this.side1=side1;
		this.side2=side2;
		this.side3=side3;
	}
	

	@Override
	public double calculateArea() {
		float s=(side1+side2+side3)/2.0f;
		System.out.println(s*(s-side1)*(s-side2)*(s-side3));
		
		return Math.sqrt(s*(s-side1)*(s-side2)*(s-side3));
	}

	@Override
	public double calculatePerimeter() {
		System.out.println(side1+" "+side2+" "+side3);
		return side1+side2+side3;
	}

}
