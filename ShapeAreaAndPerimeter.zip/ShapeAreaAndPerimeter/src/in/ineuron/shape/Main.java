package in.ineuron.shape;

public class Main {
	
	public static void main(String[] args) {
		
		Shape shape = new Circle(21);
		
		System.out.println("The area of circle : "+shape.calculateArea());
		System.out.println("The Perimeter of circle : "+shape.calculatePerimeter());
		
		System.out.println();
		
		shape = new Triangle(6.0f,7.0f,9.0f);
		
		System.out.println("The area of traingle : "+shape.calculateArea());
		System.out.println("The perimeter of circle : "+shape.calculatePerimeter());
	}

}
