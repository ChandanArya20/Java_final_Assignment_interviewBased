package in.ineuron.shape;

public class Circle implements Shape{
	
	//variables for storing radius of circle
	private float radius;
	
	final float PI=3.14f;
	
	//constructor for initialize the variable
	Circle(float radius){	
		this.radius=radius;
	}
	
	@Override
	public double calculateArea() {
		
		return PI*radius*radius;
	}

	@Override
	public double calculatePerimeter() {
		
		return 2*PI*radius;
	}

}
