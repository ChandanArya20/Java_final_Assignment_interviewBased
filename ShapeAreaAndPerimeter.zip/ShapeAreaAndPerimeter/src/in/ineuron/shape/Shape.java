package in.ineuron.shape;

public interface Shape {
	
	double calculateArea();
	double calculatePerimeter();

}
