package in.ineuron.main;

import java.util.Scanner;

import in.ineuron.bankaccount.BankAccount;

public class Main {

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		BankAccount account =null;
		
        int choice;
        while(true){
    	
	        System.out.println("\n_______Bank Account Menu_______\n");
	        System.out.println("1. Create a account");
	        System.out.println("2. Deposit");
	        System.out.println("3. Withdraw");
	        System.out.println("4. Check Balance");
	        System.out.println("5. Exit");
	        System.out.print("Enter your choice: ");
	        choice = scanner.nextInt();

        switch (choice) {
            case 1:
            	System.out.print("Create Bank Account Number : ");
        		String accountNumber=scanner.next();       		
        		account = new BankAccount(accountNumber);
        		System.out.println("You account created with acoount number : "+accountNumber);
                break;
            case 2:
            	System.out.print("Enter amount to deposit: ");
                double depositAmount = scanner.nextDouble();
                account.deposit(depositAmount);
                break;
            case 3:
            	System.out.print("Enter amount to withdraw: ");
            	double withdrawAmount = scanner.nextDouble();
            	account.withdraw(withdrawAmount);
            	break;
            case 4:
                account.checkBalance();
                break;
            case 5:
                System.out.println("Program got Exited, try again...");
                System.exit(0);
            default:
                System.out.println("Invalid choice, Please try again.");
        }
    }


	}

}
