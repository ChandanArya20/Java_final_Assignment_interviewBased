package in.ineuron.bankaccount;

public class BankAccount {

	private String accountNumber;
	private double balance=0;
	
	public BankAccount(String accountNumber){
		this.accountNumber=accountNumber;
	}
	
	public void deposit(double amt) {
		if(amt>=0) {
			balance+=amt;
			System.out.println("Deposit for amount "+amt+", successfull...");
		}else
			System.out.println("Deposit for amount "+amt+", failed...");
	}
	public void withdraw(double amt) {
		if(amt<=balance) {
			balance-=amt;
			System.out.println("withdraw for amount "+amt+", successfull...");
		}else
			System.out.println("Insufficient amount, withdraw got failed...");
	}
	
	public void checkBalance() {
		System.out.println("You Account Balaance : "+balance);
	}
}
