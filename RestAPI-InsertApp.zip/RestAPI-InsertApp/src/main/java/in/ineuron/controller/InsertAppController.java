package in.ineuron.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import in.ineuron.model.Student;
import in.ineuron.repo.IStudentRepo;

@RestController
public class InsertAppController {
	
	@Autowired
	IStudentRepo repo;
	
	@PostMapping("/save")
	public ResponseEntity<Student> insertRecord(@RequestBody Student std) {
		System.out.println("InsertAppController.insertRecord()");
		try {
			Student savedStudent = repo.save(std);
//			return ResponseEntity.of(Optional.of(savedStudent));
			return new ResponseEntity<Student>(savedStudent,HttpStatus.OK);
			
			
		}catch(Exception e) {
			e.printStackTrace();
//			return ResponseEntity.internalServerError().build();
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
		}
	}

}
