package in.ineuron.main;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import in.ineuron.model.Student;

public class RetrieveApp {

	public static void main(String[] args) {
		
		SessionFactory sessionFactory =null;
		Session session =null;
//		Transaction transaction=null;
		boolean flag=false;
		
		try {
			sessionFactory = new Configuration().configure().addAnnotatedClass(Student.class).buildSessionFactory();
			
			if(sessionFactory!=null)
				session = sessionFactory.openSession();			
			
//			transaction = session.beginTransaction();
			session.beginTransaction();
						
			Student std = new Student();
			std.setSname("Ram");
			std.setSage(25);
			std.setSaddress("Ayodhya");	
			
			session.save(std);
			session.getTransaction().commit();
						
			Student student = session.get(Student.class, std.getSid());
			System.out.println("Stdent name    : "+student.getSname());
			System.out.println("Stdent age     : "+student.getSage());
			System.out.println("Stdent address : "+student.getSaddress());
			
		} catch(Exception e) {
			e.printStackTrace();
		} finally {	
			
//			if(flag) {
//				session.getTransaction().commit();				
//			} else
//				session.getTransaction().rollback();
			
			if(session!=null)
				session.close();
			
			if(sessionFactory!=null)
				sessionFactory.close();
		}
	}
}





