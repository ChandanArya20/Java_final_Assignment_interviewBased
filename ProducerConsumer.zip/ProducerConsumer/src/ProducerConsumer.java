
import java.util.LinkedList;
import java.util.Queue;
import java.util.Random;

class MyQueue {
	
    private final Queue<Integer> queue;
    private final int capacity;

    public MyQueue(int capacity) {
        this.queue = new LinkedList<>();
        this.capacity = capacity;
    }

    public synchronized void produce() throws InterruptedException {
        while (queue.size() == capacity) {
            wait();
        }

        // Generate a random number
        Random random = new Random();
        int number = random.nextInt(100);

        // Add the number to the queue
        queue.add(number);
        System.out.println("Produced: " + number);

        // Notify consumer thread that an item is available
        notify(); // Notify the consumer thread waiting in consume()
    }


    public synchronized void consume() throws InterruptedException {
        while (queue.isEmpty()) {
            wait();
        }

        // Calculate the sum of numbers in the queue
        int sum = 0;
        for (int number : queue) {
            sum += number;
        }

        System.out.println("Consumed - Sum: " + sum);

        // Clear the queue after consuming
        queue.clear();

        // Notify producer thread that space is available in the buffer
        notify(); // Notify the producer thread waiting in produce()
    }

}

class Producer implements Runnable {
    private final MyQueue queue;

    public Producer(MyQueue queue) {
        this.queue = queue;
    }

    public void run() {
        try {
            for (int i = 0; i < 10; i++) {
            	queue.produce();
//                Thread.sleep(100);
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}

class Consumer implements Runnable {
    private final MyQueue queue;

    public Consumer(MyQueue queue) {
        this.queue = queue;
    }

    public void run() {
        try {
            for (int i = 0; i < 10; i++) {
            	queue.consume();
                Thread.sleep(1000);
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}

public class ProducerConsumer {
    public static void main(String[] args) {
    	MyQueue buffer = new MyQueue(5);

        // Create producer thread
        Thread producerThread = new Thread(new Producer(buffer));

        // Create consumer thread
        Thread consumerThread = new Thread(new Consumer(buffer));
        
        //Starting both thread
        producerThread.start();
        consumerThread.start();
    }
}

