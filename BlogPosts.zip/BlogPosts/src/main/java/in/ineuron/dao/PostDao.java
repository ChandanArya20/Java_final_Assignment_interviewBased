package in.ineuron.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import in.ineuron.model.Post;

public class PostDao {
	
	private static String url="jdbc:mysql://localhost:3306/studentproject";
	private static String userName="root";
	private static String password="2002ckc+";
	
	private static Connection connection=null;
	private static PreparedStatement pstm=null;
	private static ResultSet resultSet =null;
	
	static {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			connection=DriverManager.getConnection(url,userName,password);
		} catch (SQLException | ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	public int savePost(Post post) {
			
		String query ="insert into POSTS(title,description,content)values(?,?,?)";		
		try {			
			if(connection!=null)
				pstm=connection.prepareStatement(query);
		 
			if(pstm!=null) {
				pstm.setString(1, post.getTitle());
				pstm.setString(2, post.getDescription());
				pstm.setString(3, post.getContent());
				
				return pstm.executeUpdate();
			}
			
		} catch (SQLException  e) {	
			e.printStackTrace();
			return 0;
		}
		return 0;
		
	}
	public List<Post> showAllPost() {
		
		String query ="SELECT * FROM posts";
		List<Post> posts=new ArrayList<>();
		
		try {		
			if(connection!=null)
				pstm=connection.prepareStatement(query);
			
			if(pstm!=null) 
				resultSet = pstm.executeQuery();
			
			while(resultSet.next()) {
				Post post = new Post();
				post.setTitle(resultSet.getString(2));
				post.setDescription(resultSet.getString(3));
				post.setContent(resultSet.getString(4));
									
				posts.add(post);
			}				
								
		} catch (SQLException e) {
			e.printStackTrace();
			return posts;
			
		}
		return posts;
	}

}
