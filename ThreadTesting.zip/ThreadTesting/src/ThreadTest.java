public class ThreadTest {

	public static void main(String[] args) {
		
		// Creating evenThread using lambda expression
		Thread evenThread = new Thread(() -> {
			for (int i = 1; i <= 10; i++) {
				if (i % 2 == 0) {
					System.out.println("Even: " + i);
				}
			}
		});

		// Creating oddThread using lambda expression
		Thread oddThread = new Thread(() -> {
			for (int i = 1; i <= 10; i++) {
				if (i % 2 != 0) {
					System.out.println("Odd: " + i);
				}
			}
		});

		// Starting the threads
		evenThread.start();
		oddThread.start();
	}

}

